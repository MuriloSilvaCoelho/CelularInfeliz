
import celularfeliz.Cliente;
import celularfeliz.Funcionario;
import celularfeliz.util.StatusOrdemServico;
import celularfeliz.util.StatusServico;
import java.util.List;


public class OrdemServico {
    
    private int id;
    private Cliente cliente;
    private List <Servico> servicos;
    private Funcionario funcionario;
    private double valororcamento;
    private StatusOrdemServico status;
    private String observacao;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List getServicos() {
        return servicos;
    }

    public void setServicos(List servicos) {
        this.servicos = servicos;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public double getValororcamento() {
        return valororcamento;
    }

    public void setValororcamento(double valororcamento) {
        this.valororcamento = valororcamento;
    }

    public StatusOrdemServico getStatus() {
        return status;
    }

    public void setStatus(StatusOrdemServico status) {
        this.status = status;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public void adicionarServico (Servico servico) {
            servicos.add(servico);
        };
    
    public void removerServico (Servico servico) {
        servicos.remove(servico);
};
    
    public void aprovarOrcamento () {

    if (status == StatusOrdemServico.ANALISANDO) {
        status = StatusOrdemServico.APROVADO;
        };
    }
    
    public void reprovarOrcamento () {

    if (status == StatusOrdemServico.ANALISANDO) {
        status = StatusOrdemServico.REPROVADO;
        };
    }
    
    public void calcularValorOrcamento() {

        valorOrcamento = 0;

        for (Servico servico : servicos) {

            if (servico.getStatus() == StatusServico.INCLUIDO) {
                valorOrcamento += servico.getValor();
            }
        }
    }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
    
}
