/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package celularfeliz;

/**
 *
 * @author alunocmc
 */
public class Pessoa {
    protected int id;
    protected String nome;
    protected String email;
    protected StatusPessoa status;
    
    
    
    
}
