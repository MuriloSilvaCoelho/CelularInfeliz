/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package celularfeliz;

import celularfeliz.util.StatusServico;

/**
 *
 * @author alunocmc
 */
public class Servico {
    private int id;
    private String descricao;
    private double valorbase;
    private Categoria categoria;
    private StatusServico status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValorbase() {
        return valorbase;
    }

    public void setValorbase(double valorbase) {
        this.valorbase = valorbase;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public StatusServico getStatus() {
        return status;
    }

    public void setStatus(StatusServico status) {
        this.status = status;
    }
    
    public void executarServico() {
    if (status == StatusServico.INCLUÍDO) {
        status = StatusServico.EXECUTANDO;
    };
    }
    
    public void concluirServico() {
        if (status == StatusServico.EXECUTANDO) {
        status = StatusServico.CONCLUÍDO;};
}
}

