/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package celularfeliz;

import celularfeliz.util.StatusPagamento;

/**
 *
 * @author jmmur
 */
public class Pagamento {
    private StatusPagamento status;
    
    public OrdemServico efetuarPagamento(OrdemServico ordemservico) {
        return ordemservico;
    }
    
    public StatusPagamento getStatus() {
    return status;
}

}
